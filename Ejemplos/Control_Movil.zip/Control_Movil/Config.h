#include "Arduino.h"
#define NUMEROPARAMETROS 5
#define LONGMAXPARAMETRO 6
#define NOMBREDISPOSITIVO "ArduinoBT"

extern char ordenBt[];              // Array donde recibimos la orden por bluetooth.
extern char *trozo;                 // Variable para almacenar los parámetros.
extern char separador[];            // Separadores
extern bool mensajeRecibido;
extern byte contador;
extern byte numeroFunciones;
// Array para almacenar los parámetros pasados por bluetooth
extern char parametros[NUMEROPARAMETROS][LONGMAXPARAMETRO + 1];