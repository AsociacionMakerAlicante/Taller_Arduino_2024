#include "MisFunciones.h"

funcion Mis_Funciones[]{ &Blink
                , &Encender
                , &Apagar};

byte numeroFunciones = sizeof(Mis_Funciones)/sizeof(funcion);
// Lee los datos recibidos por bluetooth y guarda el comando y los parámetros en una estructura "mensajeBT"
void LecturaComando()
{
  // Antes de leer los nuevos parámetros borramos los anteriores.
  memset(parametros, 0, sizeof(parametros));

  contador = 0;
  // La cadena puede tener distintos valores separados por "," (coma).
  // Leemos el comando y los parámetros uno a uno.
  // Cargamos el primer parámetro de la cadena.
  // El primer valor siempre es el comando.
  trozo = strtok(ordenBt, separador);

  // Estamos leyendo mientras hay parámetros o hasta el máximo número de parámetros
  // para no desbordar el array.
  while (trozo != NULL && contador < NUMEROPARAMETROS)
  {
    // Copiamos el valor de trozo al array de comandos en el índice correspondiente.
    memcpy(parametros[contador], trozo, LONGMAXPARAMETRO);

    // Cargamos en "trozo" el siguiente parámetro de la cadena.
    trozo = strtok(NULL, separador);
    contador++;
  }
}

void Blink(){
    Serial.println("Ejecutando función blink.");
};

void Encender(){
    Serial.println("Ejecutando función Encender.");
}

void Apagar(){
    Serial.println("Ejecutando función Apagar.");
}